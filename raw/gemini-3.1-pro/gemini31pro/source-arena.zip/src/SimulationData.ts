import * as d3 from 'd3-geo';

export type Position = [number, number];

export const ASCENSION: Position = [-14.4167, -7.9333];
export const FALKLANDS: Position = [-57.85, -51.6917];

const outboundLerp = d3.geoInterpolate(ASCENSION, FALKLANDS);

export const waypoints = {
  W1: outboundLerp(5 / 45),
  W2: outboundLerp(12 / 45),
  W3: outboundLerp(20 / 45),
  W4: outboundLerp(28 / 45),
  W5: outboundLerp(35 / 45), // Final outbound refuel
  W6: outboundLerp(15 / 45)  // Return refuel (approx 1/3 distance from Ascension)
};

export type Keyframe = { t: number; pos: Position };

export type AircraftGroup = {
  id: string;
  name: string;
  type: 'vulcan' | 'victor' | 'return-victor';
  count: number;
  keyframes: Keyframe[];
  color: string;
};

// Colors
const COLOR_VULCAN = '#ef4444'; // red-500
const COLOR_VICTOR = '#3b82f6'; // blue-500
const COLOR_RETURN = '#f59e0b'; // amber-500

export const aircraftGroups: AircraftGroup[] = [
  {
    id: 'vulcan',
    name: 'Vulcan (XM607)',
    type: 'vulcan',
    count: 1,
    color: COLOR_VULCAN,
    keyframes: [
      { t: 0, pos: ASCENSION },
      { t: 5, pos: waypoints.W1 },
      { t: 12, pos: waypoints.W2 },
      { t: 20, pos: waypoints.W3 },
      { t: 28, pos: waypoints.W4 },
      { t: 35, pos: waypoints.W5 },
      { t: 45, pos: FALKLANDS }, // Bombing
      { t: 75, pos: waypoints.W6 }, // Rendezvous
      { t: 90, pos: ASCENSION }
    ]
  },
  {
    id: 'victors-1',
    name: 'Victor Wave 1',
    type: 'victor',
    count: 4,
    color: COLOR_VICTOR,
    keyframes: [
      { t: 0, pos: ASCENSION },
      { t: 5, pos: waypoints.W1 },
      { t: 10, pos: ASCENSION }
    ]
  },
  {
    id: 'victors-2',
    name: 'Victor Wave 2',
    type: 'victor',
    count: 3,
    color: COLOR_VICTOR,
    keyframes: [
      { t: 0, pos: ASCENSION },
      { t: 12, pos: waypoints.W2 },
      { t: 24, pos: ASCENSION }
    ]
  },
  {
    id: 'victors-3',
    name: 'Victor Wave 3',
    type: 'victor',
    count: 2,
    color: COLOR_VICTOR,
    keyframes: [
      { t: 0, pos: ASCENSION },
      { t: 20, pos: waypoints.W3 },
      { t: 40, pos: ASCENSION }
    ]
  },
  {
    id: 'victors-4',
    name: 'Victor Wave 4',
    type: 'victor',
    count: 1,
    color: COLOR_VICTOR,
    keyframes: [
      { t: 0, pos: ASCENSION },
      { t: 28, pos: waypoints.W4 },
      { t: 56, pos: ASCENSION }
    ]
  },
  {
    id: 'victors-5',
    name: 'Final Tanker',
    type: 'victor',
    count: 1,
    color: COLOR_VICTOR,
    keyframes: [
      { t: 0, pos: ASCENSION },
      { t: 35, pos: waypoints.W5 },
      { t: 70, pos: ASCENSION }
    ]
  },
  {
    id: 'return-victors',
    name: 'Return Tankers',
    type: 'return-victor',
    count: 2,
    color: COLOR_RETURN,
    keyframes: [
      { t: 60, pos: ASCENSION },
      { t: 75, pos: waypoints.W6 },
      { t: 90, pos: ASCENSION }
    ]
  }
];

export const getAircraftPos = (group: AircraftGroup, t: number): Position | null => {
  const kfs = group.keyframes;
  if (t < kfs[0].t || t > kfs[kfs.length - 1].t) {
    return null; // Not active
  }

  for (let i = 0; i < kfs.length - 1; i++) {
    const k1 = kfs[i];
    const k2 = kfs[i + 1];
    if (t >= k1.t && t <= k2.t) {
      const progress = (t - k1.t) / (k2.t - k1.t);
      const lerp = d3.geoInterpolate(k1.pos, k2.pos);
      return lerp(progress);
    }
  }
  return kfs[kfs.length - 1].pos;
};

export const getEvents = (t: number) => {
  if (t < 2) return "Takeoff from Wideawake Airfield, Ascension Island. 1 Vulcan and 11 Victor Tankers.";
  if (t >= 4 && t < 7) return "Wave 1 Refuelling: 4 Victors refuel the others and return to base.";
  if (t >= 11 && t < 14) return "Wave 2 Refuelling: 3 Victors transfer fuel and peel off.";
  if (t >= 19 && t < 22) return "Wave 3 Refuelling: 2 more Victors transfer fuel and return.";
  if (t >= 27 && t < 30) return "Wave 4 Refuelling: 1 Victor transfers fuel, leaving only the Final Tanker.";
  if (t >= 34 && t < 37) return "Final Refuel: The last Victor tops up the Vulcan and turns back on fumes.";
  if (t >= 44 && t < 47) return "BOMBING RUN: Vulcan XM607 bombs Port Stanley airstrip, catching the defenders by surprise.";
  if (t >= 59 && t < 62) return "Return Tankers scrambled from Ascension to rendezvous with the returning Vulcan.";
  if (t >= 74 && t < 77) return "Return Rendezvous: Desperate refuelling as the Vulcan runs dangerously low on fuel.";
  if (t >= 88 && t <= 90) return "Mission Complete. Aircraft land safely at Ascension Island.";
  
  // Default states
  if (t >= 7 && t < 34) return "Formation pushes further south into radio silence. Fuel management is critical.";
  if (t >= 37 && t < 44) return "Vulcan proceeds alone towards the Falklands at low altitude.";
  if (t >= 47 && t < 59) return "Vulcan begins the long 3,900-mile journey back home.";
  if (t >= 62 && t < 74) return "Vulcan climbs to conserve fuel, desperately searching for the return tankers.";
  if (t >= 77 && t < 88) return "Vulcan and return tankers fly back together.";

  return "Operation Black Buck";
};
