import React, { useState, useEffect, useRef } from 'react';
import MapComponent from './Map';
import { getEvents } from './SimulationData';
import { Play, Pause, RotateCcw } from 'lucide-react';

function App() {
  const [time, setTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const animationRef = useRef<number>(0);
  const lastTimeRef = useRef<number>(0);

  const SIMULATION_DURATION = 90; // The total time units

  const animate = (timestamp: number) => {
    if (!lastTimeRef.current) lastTimeRef.current = timestamp;
    const deltaTime = timestamp - lastTimeRef.current;

    setTime((prevTime) => {
      // 1 time unit = 0.5 seconds (so 90 units = 45 seconds)
      const speed = 2.0; 
      let newTime = prevTime + (deltaTime / 1000) * speed;
      
      if (newTime >= SIMULATION_DURATION) {
        newTime = SIMULATION_DURATION;
        setIsPlaying(false);
      }
      return newTime;
    });

    lastTimeRef.current = timestamp;
    if (isPlaying) {
      animationRef.current = requestAnimationFrame(animate);
    }
  };

  useEffect(() => {
    if (isPlaying) {
      lastTimeRef.current = performance.now();
      animationRef.current = requestAnimationFrame(animate);
    } else {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    }
    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, [isPlaying]);

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTime(parseFloat(e.target.value));
  };

  const togglePlay = () => {
    if (time >= SIMULATION_DURATION) {
      setTime(0);
    }
    setIsPlaying(!isPlaying);
  };

  const reset = () => {
    setTime(0);
    setIsPlaying(false);
  };

  const progressPercentage = (time / SIMULATION_DURATION) * 100;
  const currentEvent = getEvents(time);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-50 font-sans p-6 flex flex-col items-center">
      <header className="max-w-6xl w-full flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
        <div>
          <h1 className="text-4xl font-extrabold tracking-tight bg-gradient-to-r from-red-500 to-amber-500 bg-clip-text text-transparent">
            Operation Black Buck
          </h1>
          <p className="text-slate-400 mt-2 max-w-2xl">
            The 8,000-mile Vulcan bomber mission to the Falkland Islands, supported by an incredible
            cascade of 11 Victor tankers.
          </p>
        </div>
        
        <div className="flex gap-4 items-center">
          <a
            href="https://en.wikipedia.org/wiki/Operation_Black_Buck"
            target="_blank"
            rel="noreferrer"
            className="text-sm text-blue-400 hover:text-blue-300 underline underline-offset-4"
          >
            Learn more
          </a>
        </div>
      </header>

      <main className="max-w-6xl w-full flex flex-col lg:flex-row gap-8 flex-1">
        
        {/* Left Column: Map */}
        <div className="flex-1 min-h-[500px] lg:min-h-[700px] flex items-center justify-center">
          <MapComponent time={time} />
        </div>

        {/* Right Column: Controls & Info */}
        <div className="w-full lg:w-96 flex flex-col gap-6">
          
          {/* Status Panel */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
              Mission Status
            </h2>
            <div className="min-h-[100px] flex items-center bg-slate-800/50 rounded-xl p-4 border border-slate-700/50">
              <p className="text-slate-200 text-lg leading-relaxed font-medium">
                {currentEvent}
              </p>
            </div>
            
            {/* Legend */}
            <div className="mt-6 flex flex-col gap-3">
              <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider">Legend</h3>
              <div className="flex items-center gap-3 text-sm">
                <div className="w-4 h-4 rounded bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.6)]"></div>
                <span>Vulcan Bomber (XM607)</span>
              </div>
              <div className="flex items-center gap-3 text-sm">
                <div className="w-4 h-4 rounded bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.6)]"></div>
                <span>Victor Tankers (Outbound)</span>
              </div>
              <div className="flex items-center gap-3 text-sm">
                <div className="w-4 h-4 rounded bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.6)]"></div>
                <span>Victor Tankers (Return)</span>
              </div>
            </div>
          </div>

          {/* Controls Panel */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl mt-auto">
            <div className="flex items-center justify-between mb-6">
              <div className="flex gap-2">
                <button
                  onClick={togglePlay}
                  className="w-12 h-12 flex items-center justify-center bg-blue-600 hover:bg-blue-500 active:bg-blue-700 rounded-full transition-colors shadow-lg shadow-blue-900/20"
                >
                  {isPlaying ? (
                    <Pause fill="currentColor" size={24} />
                  ) : (
                    <Play fill="currentColor" size={24} className="ml-1" />
                  )}
                </button>
                <button
                  onClick={reset}
                  className="w-12 h-12 flex items-center justify-center bg-slate-800 hover:bg-slate-700 active:bg-slate-600 rounded-full transition-colors"
                >
                  <RotateCcw size={20} />
                </button>
              </div>
              <div className="text-right">
                <div className="text-2xl font-mono font-bold text-blue-400">
                  {Math.floor(progressPercentage)}%
                </div>
                <div className="text-xs text-slate-500 uppercase tracking-wider">
                  Timeline
                </div>
              </div>
            </div>

            {/* Custom Slider */}
            <div className="relative w-full h-2 bg-slate-800 rounded-full mb-8 group">
              <div 
                className="absolute top-0 left-0 h-full bg-gradient-to-r from-blue-600 to-blue-400 rounded-full"
                style={{ width: `${progressPercentage}%` }}
              />
              <input
                type="range"
                min="0"
                max={SIMULATION_DURATION}
                step="0.1"
                value={time}
                onChange={handleSliderChange}
                className="absolute top-0 left-0 w-full h-full opacity-0 cursor-pointer"
              />
              {/* Slider thumb visual */}
              <div 
                className="absolute top-1/2 -translate-y-1/2 w-4 h-4 bg-white rounded-full shadow-lg pointer-events-none transition-transform group-hover:scale-125"
                style={{ left: `calc(${progressPercentage}% - 8px)` }}
              />
            </div>
            
            <div className="flex justify-between text-xs text-slate-500 font-mono">
              <span>00:00Z</span>
              <span>16:00Z</span>
            </div>
          </div>

        </div>
      </main>
    </div>
  );
}

export default App;
