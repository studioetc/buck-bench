import React, { useEffect, useState, useMemo } from 'react';
import * as d3 from 'd3-geo';
import * as topojson from 'topojson-client';
import {
  ASCENSION,
  FALKLANDS,
  aircraftGroups,
  getAircraftPos,
  AircraftGroup,
  Position,
  waypoints
} from './SimulationData';

interface MapProps {
  time: number; // 0 to 90
}

const MapComponent: React.FC<MapProps> = ({ time }) => {
  const [worldData, setWorldData] = useState<any>(null);

  useEffect(() => {
    fetch('https://unpkg.com/world-atlas@2.0.2/countries-110m.json')
      .then((res) => res.json())
      .then((data) => {
        const land = topojson.feature(data, data.objects.countries);
        setWorldData(land);
      });
  }, []);

  // Setup D3 Projection
  // We want to center between Ascension and Falklands
  const width = 800;
  const height = 800;
  
  const projection = useMemo(() => {
    return d3.geoAzimuthalEquidistant()
      .rotate([36, 30, 0]) // Center longitude / latitude (adjusted for visual)
      .scale(600)
      .translate([width / 2, height / 2]);
  }, []);

  const pathGenerator = d3.geoPath().projection(projection);
  const graticule = d3.geoGraticule()();

  // Create static flight line path (Ascension to Falklands)
  const flightLineFeature: GeoJSON.Feature<GeoJSON.LineString> = {
    type: 'Feature',
    geometry: {
      type: 'LineString',
      coordinates: [ASCENSION, FALKLANDS]
    },
    properties: {}
  };

  const getAircraftRotation = (group: AircraftGroup, t: number, currentPos: Position) => {
    // Determine heading by comparing current pos to slightly future pos
    let p1 = projection(currentPos);
    let futurePos = getAircraftPos(group, t + 0.1);
    let p2 = futurePos ? projection(futurePos) : null;
    
    if (!p2) {
      // If at the very end of the path, check a slightly past position
      const pastPos = getAircraftPos(group, t - 0.1);
      if (pastPos) {
         p2 = p1;
         p1 = projection(pastPos);
      }
    }
    
    if (!p1 || !p2 || (p1[0] === p2[0] && p1[1] === p2[1])) return 0;
    
    const dx = p2[0] - p1[0];
    const dy = p2[1] - p1[1];
    return (Math.atan2(dy, dx) * 180) / Math.PI;
  };

  return (
    <div className="relative w-full h-full bg-slate-900 rounded-xl overflow-hidden shadow-2xl border border-slate-700">
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="w-full h-full"
        style={{ filter: 'drop-shadow(0 0 20px rgba(0,0,0,0.5))' }}
      >
        {/* Graticule */}
        <path
          d={pathGenerator(graticule) || ''}
          fill="none"
          stroke="rgba(255,255,255,0.05)"
          strokeWidth={1}
        />

        {/* Landmasses */}
        {worldData && (
          <path
            d={pathGenerator(worldData) || ''}
            fill="#1e293b" // slate-800
            stroke="#334155" // slate-700
            strokeWidth={1}
          />
        )}

        {/* Flight Path Background Line */}
        <path
          d={pathGenerator(flightLineFeature) || ''}
          fill="none"
          stroke="rgba(255,255,255,0.2)"
          strokeWidth={2}
          strokeDasharray="4 4"
        />

        {/* Target Points */}
        <g transform={`translate(${projection(ASCENSION)?.join(',')})`}>
          <circle r={6} fill="#10b981" />
          <text y={-10} textAnchor="middle" fill="#10b981" className="text-sm font-bold drop-shadow-md">
            Ascension Island
          </text>
        </g>

        <g transform={`translate(${projection(FALKLANDS)?.join(',')})`}>
          <circle r={6} fill="#ef4444" className={time >= 44 && time <= 46 ? 'animate-ping' : ''} />
          <text y={20} textAnchor="middle" fill="#ef4444" className="text-sm font-bold drop-shadow-md">
            Port Stanley (Falklands)
          </text>
        </g>

        {/* Aircraft */}
        {aircraftGroups.map((group) => {
          const pos = getAircraftPos(group, time);
          if (!pos) return null;

          const projPos = projection(pos);
          if (!projPos) return null;

          const rotation = getAircraftRotation(group, time, pos);

          return (
            <g
              key={group.id}
              transform={`translate(${projPos[0]}, ${projPos[1]})`}
            >
              {/* Group Count Badge */}
              {group.count > 1 && (
                <g transform="translate(15, -15)">
                  <circle r={10} fill={group.color} />
                  <text
                    y={4}
                    textAnchor="middle"
                    fill="white"
                    fontSize={12}
                    fontWeight="bold"
                  >
                    {group.count}
                  </text>
                </g>
              )}
              
              {/* Airplane Icon */}
              <g transform={`rotate(${rotation})`}>
                <g 
                  transform="scale(0.8) translate(-15, -15)"
                  style={{ filter: `drop-shadow(0 0 8px ${group.color})` }}
                >
                  {/* Simplified jet path */}
                  <path 
                    d="M21.5,14 L16,14 L11,4 L8,4 L10,14 L4,14 L2,11 L0,11 L1.5,15 L0,19 L2,19 L4,16 L10,16 L8,26 L11,26 L16,16 L21.5,16 C22.8807119,16 24,15 24,15 C24,15 22.8807119,14 21.5,14 Z" 
                    fill={group.color} 
                    transform="translate(3, -15)"
                  />
                </g>
              </g>

              {/* Label for Vulcan */}
              {group.type === 'vulcan' && (
                <text
                  y={30}
                  textAnchor="middle"
                  fill="white"
                  className="text-xs font-bold drop-shadow-md"
                >
                  {group.name}
                </text>
              )}
            </g>
          );
        })}

        {/* Refuelling Event Pulses */}
        {[ 
          { t: 5, pos: waypoints.W1, color: '#3b82f6' },
          { t: 12, pos: waypoints.W2, color: '#3b82f6' },
          { t: 20, pos: waypoints.W3, color: '#3b82f6' },
          { t: 28, pos: waypoints.W4, color: '#3b82f6' },
          { t: 35, pos: waypoints.W5, color: '#3b82f6' },
          { t: 75, pos: waypoints.W6, color: '#f59e0b' }
        ].map((event, idx) => {
          if (time >= event.t && time < event.t + 1.5) {
            const dt = time - event.t;
            return (
              <g key={`refuel-${idx}`} transform={`translate(${projection(event.pos)?.join(',')})`}>
                 <circle r={dt * 30} fill="none" stroke={event.color} strokeWidth={3} style={{ opacity: 1 - dt/1.5 }} />
                 <text y={-20} textAnchor="middle" fill={event.color} className="text-xs font-bold font-mono" style={{ opacity: 1 - dt/1.5 }}>
                   REFUEL
                 </text>
              </g>
            );
          }
          return null;
        })}

        {/* Bombing Animation */}
        {time >= 45 && time < 48 && (
          <g transform={`translate(${projection(FALKLANDS)?.join(',')})`}>
             <circle r={20 + (time - 45) * 20} fill="none" stroke="#ef4444" strokeWidth={4} className="opacity-70" />
             <circle r={10 + (time - 45) * 40} fill="none" stroke="#ef4444" strokeWidth={2} className="opacity-40" />
             <circle r={(time - 45) * 60} fill="none" stroke="#f59e0b" strokeWidth={1} className="opacity-20" />
          </g>
        )}
      </svg>
    </div>
  );
};

export default MapComponent;
