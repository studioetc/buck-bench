import { useEffect, useMemo, useState } from "react";
import type { CSSProperties } from "react";

type Point = { x: number; y: number };
type Wave = "wave1" | "wave2" | "recovery";

type RefuelNode = {
  id: string;
  label: string;
  at: number;
  leg: "outbound" | "return";
  s: number;
  title: string;
  detail: string;
  kind: "vulcan" | "relay" | "recovery";
};

type Phase = {
  at: number;
  kicker: string;
  title: string;
  detail: string;
};

type FlightPlan = {
  id: string;
  wave: Wave;
  label: string;
  endS: number;
  launch: number;
  lane: number;
  hold?: number;
  meetTime?: number;
  landTime?: number;
};

type AircraftState = {
  point: Point;
  angle: number;
  label: string;
  wave?: Wave;
  active?: boolean;
  dimmed?: boolean;
  scale?: number;
};

const ASCENSION: Point = { x: 640, y: 126 };
const STANLEY: Point = { x: 344, y: 628 };
const OUTBOUND_END = 0.58;
const TOTAL_HOURS = 16;
const ONE_WAY_KM = 6400;

const OUT_CP1: Point = { x: 760, y: 262 };
const OUT_CP2: Point = { x: 438, y: 430 };
const RETURN_CP1: Point = { x: 466, y: 552 };
const RETURN_CP2: Point = { x: 704, y: 324 };

const routePathOutbound = `M ${ASCENSION.x} ${ASCENSION.y} C ${OUT_CP1.x} ${OUT_CP1.y}, ${OUT_CP2.x} ${OUT_CP2.y}, ${STANLEY.x} ${STANLEY.y}`;
const routePathReturn = `M ${STANLEY.x} ${STANLEY.y} C ${RETURN_CP1.x} ${RETURN_CP1.y}, ${RETURN_CP2.x} ${RETURN_CP2.y}, ${ASCENSION.x} ${ASCENSION.y}`;

const phases: Phase[] = [
  {
    at: 0,
    kicker: "Tanker stream",
    title: "Wideawake launches the whole chain.",
    detail:
      "Two Vulcans and a layered Victor tanker force leave Ascension. The map exaggerates lateral spacing so the relay is readable.",
  },
  {
    at: 0.12,
    kicker: "Reserve becomes primary",
    title: "XM607 takes over the raid.",
    detail:
      "The planned lead Vulcan, XM598, turns back after pressurisation trouble. The spare Vulcan, XM607, continues south.",
  },
  {
    at: 0.2,
    kicker: "Cascading fuel",
    title: "Victors refuel Victors first.",
    detail:
      "Early tankers give fuel to the next layer, then peel home. This is the essence of the Black Buck refuelling plan.",
  },
  {
    at: 0.34,
    kicker: "Vulcan top-offs",
    title: "The bomber is passed from layer to layer.",
    detail:
      "XM607 is kept heavy enough to reach the next rendezvous while the tanker count thins behind it.",
  },
  {
    at: 0.49,
    kicker: "Last outbound relay",
    title: "The chain stretches to its limit.",
    detail:
      "The final southbound handoffs leave the deepest Victor with just enough margin to turn north again.",
  },
  {
    at: OUTBOUND_END,
    kicker: "Target run",
    title: "Port Stanley runway is attacked.",
    detail:
      "The Vulcan crosses the airfield and drops twenty-one 1,000 lb bombs. The raid records one runway hit.",
  },
  {
    at: 0.69,
    kicker: "Recovery wave",
    title: "Tankers launch to bring XM607 home.",
    detail:
      "The return leg is not just a flight home: recovery Victors head south to meet the bomber and the remaining tankers.",
  },
  {
    at: 0.9,
    kicker: "Ascension recovery",
    title: "The relay collapses back to Wideawake.",
    detail:
      "After nearly sixteen hours in the air, the bomber and last tankers return to Ascension.",
  },
];

const refuelNodes: RefuelNode[] = [
  {
    id: "R1",
    label: "1",
    at: 0.15,
    leg: "outbound",
    s: 0.14,
    title: "First top-up",
    detail: "Initial post-launch fuel shuffling keeps the southbound package full.",
    kind: "relay",
  },
  {
    id: "R2",
    label: "2",
    at: 0.22,
    leg: "outbound",
    s: 0.25,
    title: "Tanker-to-tanker relay",
    detail: "Victors pass fuel forward, then reverse course for Ascension.",
    kind: "relay",
  },
  {
    id: "R3",
    label: "3",
    at: 0.3,
    leg: "outbound",
    s: 0.38,
    title: "XM607 takes another load",
    detail: "The bomber remains on the center route while tankers occupy staggered lanes.",
    kind: "vulcan",
  },
  {
    id: "R4",
    label: "4",
    at: 0.38,
    leg: "outbound",
    s: 0.52,
    title: "Middle Atlantic handoff",
    detail: "The relay is now several hours south of Ascension and early Victors are already returning.",
    kind: "vulcan",
  },
  {
    id: "R5",
    label: "5",
    at: 0.46,
    leg: "outbound",
    s: 0.68,
    title: "Deep outbound refuel",
    detail: "Only the deeper tankers remain with the Vulcan.",
    kind: "vulcan",
  },
  {
    id: "R6",
    label: "6",
    at: 0.52,
    leg: "outbound",
    s: 0.83,
    title: "Last fuel before the run-in",
    detail: "The final outbound margin is set before the bomber descends toward the Falklands.",
    kind: "vulcan",
  },
  {
    id: "TGT",
    label: "T",
    at: OUTBOUND_END,
    leg: "outbound",
    s: 1,
    title: "Target",
    detail: "Port Stanley airfield is reached at the far end of the chain.",
    kind: "vulcan",
  },
  {
    id: "R7",
    label: "7",
    at: 0.73,
    leg: "return",
    s: 0.43,
    title: "Return refuel",
    detail: "A recovery Victor meets the returning bomber north of the Falklands.",
    kind: "recovery",
  },
  {
    id: "R8",
    label: "8",
    at: 0.84,
    leg: "return",
    s: 0.73,
    title: "Final recovery margin",
    detail: "The northern recovery lane rebuilds fuel reserves for the long climb home.",
    kind: "recovery",
  },
];

const tankerFlights: FlightPlan[] = [
  { id: "V2A", wave: "wave2", label: "Victor", endS: 0.16, launch: 0.02, lane: -62, hold: 0.035 },
  { id: "V2B", wave: "wave2", label: "Victor", endS: 0.28, launch: 0.026, lane: -42, hold: 0.04 },
  { id: "V2C", wave: "wave2", label: "Victor", endS: 0.42, launch: 0.032, lane: -22, hold: 0.04 },
  { id: "V2R", wave: "wave2", label: "Reserve", endS: 0.22, launch: 0.046, lane: -82, hold: 0.028 },
  { id: "V1A", wave: "wave1", label: "Victor", endS: 0.22, launch: 0.04, lane: 24, hold: 0.04 },
  { id: "V1B", wave: "wave1", label: "Victor", endS: 0.34, launch: 0.048, lane: 44, hold: 0.045 },
  { id: "V1C", wave: "wave1", label: "Victor", endS: 0.52, launch: 0.056, lane: 64, hold: 0.05 },
  { id: "V1D", wave: "wave1", label: "Victor", endS: 0.68, launch: 0.064, lane: 84, hold: 0.05 },
  { id: "V1E", wave: "wave1", label: "Victor", endS: 0.83, launch: 0.072, lane: 104, hold: 0.055 },
  { id: "RC1", wave: "recovery", label: "Recovery", endS: 0.35, launch: 0.63, lane: -34, meetTime: 0.72, landTime: 0.91 },
  { id: "RC2", wave: "recovery", label: "Recovery", endS: 0.48, launch: 0.66, lane: -58, meetTime: 0.76, landTime: 0.95 },
  { id: "RC3", wave: "recovery", label: "Recovery", endS: 0.68, launch: 0.7, lane: -82, meetTime: 0.83, landTime: 1 },
];

const waveColors: Record<Wave, string> = {
  wave1: "#ff5b6e",
  wave2: "#4ea6ff",
  recovery: "#6ee779",
};

const sources = [
  {
    name: "RAF Museum collection object X008-4556",
    note: "18 tanker sorties, 11 outward and 7 on return, one runway hit.",
    href: "https://collections.rafmuseum.org.uk/collection/object/object-458112/",
  },
  {
    name: "RAF Museum air-to-air refuelling in the Falklands War",
    note: "Victor K.2 tanker context, Vulcan refuelling problems, and the 16 hour Black Buck scale.",
    href: "https://www.rafmuseum.org.uk/blog/air-to-air-refuelling-in-the-falklands-war/",
  },
  {
    name: "RAF Stories: The Black Buck refuelling plan",
    note: "Over 12,000 km, 18 refuellings, one target, and the 7,000 kg per hour fuel burn figure.",
    href: "https://www.rafstories.org/story/raf-wp-32631",
  },
];

function clamp(value: number, min = 0, max = 1) {
  return Math.min(max, Math.max(min, value));
}

function easeInOut(value: number) {
  const t = clamp(value);
  return t * t * (3 - 2 * t);
}

function cubic(p0: Point, p1: Point, p2: Point, p3: Point, t: number): Point {
  const u = 1 - t;
  const tt = t * t;
  const uu = u * u;
  const uuu = uu * u;
  const ttt = tt * t;
  return {
    x: uuu * p0.x + 3 * uu * t * p1.x + 3 * u * tt * p2.x + ttt * p3.x,
    y: uuu * p0.y + 3 * uu * t * p1.y + 3 * u * tt * p2.y + ttt * p3.y,
  };
}

function cubicDerivative(p0: Point, p1: Point, p2: Point, p3: Point, t: number): Point {
  const u = 1 - t;
  return {
    x:
      3 * u * u * (p1.x - p0.x) +
      6 * u * t * (p2.x - p1.x) +
      3 * t * t * (p3.x - p2.x),
    y:
      3 * u * u * (p1.y - p0.y) +
      6 * u * t * (p2.y - p1.y) +
      3 * t * t * (p3.y - p2.y),
  };
}

function angleFromVector(vector: Point, reverse = false) {
  const angle = (Math.atan2(vector.y, vector.x) * 180) / Math.PI;
  return reverse ? angle + 180 : angle;
}

function outboundPoint(s: number) {
  return cubic(ASCENSION, OUT_CP1, OUT_CP2, STANLEY, clamp(s));
}

function returnPoint(s: number) {
  return cubic(STANLEY, RETURN_CP1, RETURN_CP2, ASCENSION, clamp(s));
}

function outboundAngle(s: number, reverse = false) {
  return angleFromVector(cubicDerivative(ASCENSION, OUT_CP1, OUT_CP2, STANLEY, clamp(s)), reverse);
}

function returnAngle(s: number, reverse = false) {
  return angleFromVector(cubicDerivative(STANLEY, RETURN_CP1, RETURN_CP2, ASCENSION, clamp(s)), reverse);
}

function offsetPoint(point: Point, angle: number, offset: number): Point {
  const radians = ((angle + 90) * Math.PI) / 180;
  return {
    x: point.x + Math.cos(radians) * offset,
    y: point.y + Math.sin(radians) * offset,
  };
}

function nodePoint(node: RefuelNode) {
  return node.leg === "outbound" ? outboundPoint(node.s) : returnPoint(node.s);
}

function getActivePhase(progress: number) {
  return phases.reduce((current, phase) => (progress >= phase.at ? phase : current), phases[0]);
}

function formatMissionClock(progress: number) {
  const minutes = Math.round(progress * TOTAL_HOURS * 60);
  const hoursPart = String(Math.floor(minutes / 60)).padStart(2, "0");
  const minutesPart = String(minutes % 60).padStart(2, "0");
  return `T+${hoursPart}:${minutesPart}`;
}

function getVulcanState(progress: number): AircraftState {
  if (progress <= OUTBOUND_END) {
    const s = clamp(progress / OUTBOUND_END);
    const angle = outboundAngle(s);
    return {
      point: offsetPoint(outboundPoint(s), angle, 0),
      angle,
      label: progress < 0.12 ? "XM607 spare" : "XM607",
      scale: 1.25,
      active: true,
    };
  }

  const s = clamp((progress - OUTBOUND_END) / (1 - OUTBOUND_END));
  const angle = returnAngle(s);
  return {
    point: offsetPoint(returnPoint(s), angle, 0),
    angle,
    label: "XM607",
    scale: 1.25,
    active: true,
  };
}

function getReserveVulcanState(progress: number): AircraftState | null {
  if (progress < 0.025 || progress > 0.29) return null;
  if (progress <= 0.13) {
    const s = 0.18 * easeInOut((progress - 0.025) / 0.105);
    const angle = outboundAngle(s);
    return {
      point: offsetPoint(outboundPoint(s), angle, 38),
      angle,
      label: "XM598",
      dimmed: progress > 0.105,
      scale: 1,
    };
  }
  const s = 0.18 * (1 - easeInOut((progress - 0.13) / 0.16));
  const angle = outboundAngle(s, true);
  return {
    point: offsetPoint(outboundPoint(s), angle, -38),
    angle,
    label: "XM598 returns",
    dimmed: true,
    scale: 0.95,
  };
}

function getTankerState(flight: FlightPlan, progress: number): AircraftState | null {
  if (flight.wave === "recovery") {
    if (progress < flight.launch) return null;
    const meetTime = flight.meetTime ?? 0.75;
    const landTime = flight.landTime ?? 0.96;
    const transferEnd = Math.min(landTime - 0.09, meetTime + 0.045);

    if (progress <= meetTime) {
      const u = easeInOut((progress - flight.launch) / (meetTime - flight.launch));
      const s = 1 - (1 - flight.endS) * u;
      const angle = returnAngle(s, true);
      return {
        point: offsetPoint(returnPoint(s), angle, flight.lane),
        angle,
        label: flight.label,
        wave: flight.wave,
        active: Math.abs(progress - meetTime) < 0.035,
        scale: 0.85,
      };
    }

    if (progress <= transferEnd) {
      const angle = returnAngle(flight.endS);
      return {
        point: offsetPoint(returnPoint(flight.endS), angle, flight.lane),
        angle,
        label: flight.label,
        wave: flight.wave,
        active: true,
        scale: 0.85,
      };
    }

    if (progress <= landTime) {
      const u = easeInOut((progress - transferEnd) / (landTime - transferEnd));
      const s = flight.endS + (1 - flight.endS) * u;
      const angle = returnAngle(s);
      return {
        point: offsetPoint(returnPoint(s), angle, flight.lane),
        angle,
        label: flight.label,
        wave: flight.wave,
        dimmed: progress > landTime - 0.05,
        scale: 0.85,
      };
    }

    return null;
  }

  if (progress < flight.launch) return null;
  const endTime = 0.065 + flight.endS * 0.57;
  const transferEnd = endTime + (flight.hold ?? 0.04);
  const landTime = Math.min(0.92, transferEnd + 0.13 + flight.endS * 0.25);

  if (progress <= endTime) {
    const u = easeInOut((progress - flight.launch) / (endTime - flight.launch));
    const s = flight.endS * u;
    const angle = outboundAngle(s);
    return {
      point: offsetPoint(outboundPoint(s), angle, flight.lane),
      angle,
      label: flight.label,
      wave: flight.wave,
      active: Math.abs(progress - endTime) < 0.035,
      scale: 0.82,
    };
  }

  if (progress <= transferEnd) {
    const angle = outboundAngle(flight.endS, true);
    return {
      point: offsetPoint(outboundPoint(flight.endS), angle, flight.lane),
      angle,
      label: flight.label,
      wave: flight.wave,
      active: true,
      scale: 0.82,
    };
  }

  if (progress <= landTime) {
    const u = easeInOut((progress - transferEnd) / (landTime - transferEnd));
    const s = flight.endS * (1 - u);
    const angle = outboundAngle(s, true);
    return {
      point: offsetPoint(outboundPoint(s), angle, flight.lane),
      angle,
      label: flight.label,
      wave: flight.wave,
      dimmed: progress > landTime - 0.06,
      scale: 0.82,
    };
  }

  return null;
}

function usePlayback(speed: number, progress: number, setProgress: (updater: (current: number) => number) => void) {
  const [isPlaying, setIsPlaying] = useState(true);

  useEffect(() => {
    if (!isPlaying) return;
    let frame = 0;
    let previous = performance.now();
    const tick = (now: number) => {
      const delta = now - previous;
      previous = now;
      setProgress((current) => clamp(current + delta / (70000 / speed)));
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [isPlaying, setProgress, speed]);

  useEffect(() => {
    if (progress >= 1) setIsPlaying(false);
  }, [progress]);

  return [isPlaying, setIsPlaying] as const;
}

export default function App() {
  const [progress, setProgress] = useState(0.015);
  const [speed, setSpeed] = useState(1);
  const [isPlaying, setIsPlaying] = usePlayback(speed, progress, setProgress);

  const activePhase = useMemo(() => getActivePhase(progress), [progress]);
  const activeRefuel = useMemo(
    () => refuelNodes.find((node) => Math.abs(progress - node.at) < 0.035),
    [progress],
  );
  const tankers = useMemo(
    () => tankerFlights.map((flight) => getTankerState(flight, progress)).filter(Boolean) as AircraftState[],
    [progress],
  );

  const vulcan = getVulcanState(progress);
  const reserveVulcan = getReserveVulcanState(progress);
  const refuelsComplete = refuelNodes.filter((node) => progress >= node.at && node.id !== "TGT").length;
  const legFraction = progress <= OUTBOUND_END ? progress / OUTBOUND_END : 1 - (progress - OUTBOUND_END) / (1 - OUTBOUND_END);
  const distanceFromAscension = Math.round(clamp(legFraction) * ONE_WAY_KM);

  const handlePlay = () => {
    if (progress >= 1) setProgress(() => 0);
    setIsPlaying((value) => !value);
  };

  return (
    <main className="min-h-screen overflow-hidden bg-[#020814] text-slate-100 selection:bg-cyan-300 selection:text-slate-950">
      <section className="relative min-h-screen overflow-hidden">
        <div className="absolute inset-0">
          <MissionMap
            progress={progress}
            tankers={tankers}
            vulcan={vulcan}
            reserveVulcan={reserveVulcan}
            activeRefuel={activeRefuel}
          />
        </div>

        <div className="relative z-10 flex min-h-screen flex-col">
          <header className="mx-auto flex w-full max-w-7xl items-center justify-between px-5 py-5 text-xs uppercase tracking-[0.34em] text-cyan-100/70 sm:px-8">
            <span>Operation Black Buck</span>
            <a className="hidden transition hover:text-cyan-100 sm:block" href="#sources">
              Research notes
            </a>
          </header>

          <div className="mx-auto flex w-full max-w-7xl flex-1 items-center px-5 pb-36 pt-4 sm:px-8 lg:pb-32">
            <div className="max-w-2xl animate-rise">
              <p className="mb-5 text-sm font-semibold uppercase tracking-[0.52em] text-rose-200/90">
                Black Buck refuelling simulation
              </p>
              <h1 className="text-balance text-5xl font-semibold leading-[0.92] tracking-[-0.07em] text-white sm:text-7xl lg:text-8xl">
                The tanker ballet across the South Atlantic.
              </h1>
              <p className="mt-7 max-w-xl text-lg leading-8 text-slate-200/78 sm:text-xl">
                A readable-scale animated map of how Victor tankers relayed fuel so one Avro Vulcan could fly from
                Ascension Island to Port Stanley and back.
              </p>
              <div className="mt-9 flex flex-wrap gap-3">
                <button
                  className="group inline-flex items-center gap-3 rounded-full bg-cyan-200 px-5 py-3 text-sm font-semibold text-slate-950 shadow-[0_0_38px_rgba(103,232,249,0.35)] transition hover:bg-white"
                  onClick={handlePlay}
                >
                  <span className="grid size-7 place-items-center rounded-full bg-slate-950 text-cyan-100 transition group-hover:scale-105">
                    {isPlaying ? "II" : ">"}
                  </span>
                  {isPlaying ? "Pause mission" : progress >= 1 ? "Replay mission" : "Play mission"}
                </button>
                <button
                  className="rounded-full border border-white/20 px-5 py-3 text-sm font-semibold text-white/90 backdrop-blur transition hover:border-cyan-200/70 hover:text-cyan-100"
                  onClick={() => {
                    setProgress(() => 0.46);
                    setIsPlaying(false);
                  }}
                >
                  Jump to final outbound relay
                </button>
              </div>
            </div>
          </div>

          <ControlDock
            activePhase={activePhase}
            activeRefuel={activeRefuel}
            distanceFromAscension={distanceFromAscension}
            isPlaying={isPlaying}
            progress={progress}
            refuelsComplete={refuelsComplete}
            setIsPlaying={setIsPlaying}
            setProgress={setProgress}
            setSpeed={setSpeed}
            speed={speed}
            tankerCount={tankers.length}
          />
        </div>
      </section>

      <section className="relative border-t border-white/10 bg-[#030a16] px-5 py-20 sm:px-8" id="briefing">
        <div className="mx-auto max-w-7xl">
          <div className="grid gap-12 lg:grid-cols-[0.8fr_1.2fr] lg:items-start">
            <div>
              <p className="text-sm font-semibold uppercase tracking-[0.42em] text-cyan-200/70">Briefing</p>
              <h2 className="mt-4 text-4xl font-semibold tracking-[-0.04em] text-white sm:text-5xl">
                What the map is showing
              </h2>
            </div>
            <div className="grid gap-8 text-slate-300 md:grid-cols-2">
              <div className="border-l border-cyan-200/30 pl-6">
                <h3 className="text-xl font-semibold text-white">A relay, not a convoy</h3>
                <p className="mt-3 leading-7">
                  The Victor tankers did not simply escort the Vulcan all the way. They repeatedly refuelled each
                  other, pushed fuel forward, then turned back before running below their own safe return margins.
                </p>
              </div>
              <div className="border-l border-rose-200/30 pl-6">
                <h3 className="text-xl font-semibold text-white">Readable scale</h3>
                <p className="mt-3 leading-7">
                  Positions, lateral lanes, and timing are deliberately expanded. The official plan was a sequence of
                  fuel contacts and sorties, not a tidy map of exact tracks and fuel volumes.
                </p>
              </div>
              <div className="border-l border-emerald-200/30 pl-6">
                <h3 className="text-xl font-semibold text-white">Why it mattered</h3>
                <p className="mt-3 leading-7">
                  Port Stanley airfield was struck to deter Argentine fast jets from being based on the islands and
                  threatening the British task force from much closer range.
                </p>
              </div>
              <div className="border-l border-white/20 pl-6">
                <h3 className="text-xl font-semibold text-white">Known figures</h3>
                <p className="mt-3 leading-7">
                  RAF Museum material records 18 tanker sorties, split as 11 outward and 7 return, to put one Vulcan
                  over the target on the first Black Buck raid.
                </p>
              </div>
            </div>
          </div>

          <div className="mt-16 grid gap-5 border-y border-white/10 py-8 text-sm text-slate-300 md:grid-cols-4">
            <FactStat value="18" label="Victor tanker sorties in the RAF Museum plan" />
            <FactStat value="11 + 7" label="Outward tanker sorties plus return tanker sorties" />
            <FactStat value="16 hr" label="Approximate round-trip endurance often cited" />
            <FactStat value="21 bombs" label="1,000 lb bombs carried on the runway attack" />
          </div>
        </div>
      </section>

      <section className="bg-[#050d19] px-5 py-20 sm:px-8" id="sources">
        <div className="mx-auto max-w-7xl">
          <div className="max-w-3xl">
            <p className="text-sm font-semibold uppercase tracking-[0.42em] text-cyan-200/70">Sources</p>
            <h2 className="mt-4 text-4xl font-semibold tracking-[-0.04em] text-white sm:text-5xl">
              Research notes used for the simulation
            </h2>
            <p className="mt-5 text-lg leading-8 text-slate-300">
              The animation is an interpretive reconstruction. It uses published summary figures and the known
              tanker-chain idea rather than claiming exact fuel quantities, headings, or contact timestamps.
            </p>
          </div>

          <div className="mt-12 grid gap-6 lg:grid-cols-3">
            {sources.map((source) => (
              <a
                className="group border-t border-white/15 pt-6 text-slate-300 transition hover:border-cyan-200/70 hover:text-white"
                href={source.href}
                key={source.name}
                rel="noreferrer"
                target="_blank"
              >
                <span className="text-sm uppercase tracking-[0.26em] text-cyan-200/70">Open source</span>
                <h3 className="mt-4 text-2xl font-semibold tracking-[-0.03em] text-white group-hover:text-cyan-100">
                  {source.name}
                </h3>
                <p className="mt-4 leading-7">{source.note}</p>
              </a>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}

function MissionMap({
  activeRefuel,
  progress,
  reserveVulcan,
  tankers,
  vulcan,
}: {
  activeRefuel?: RefuelNode;
  progress: number;
  reserveVulcan: AircraftState | null;
  tankers: AircraftState[];
  vulcan: AircraftState;
}) {
  const outboundProgress = clamp(progress / OUTBOUND_END);
  const returnProgress = clamp((progress - OUTBOUND_END) / (1 - OUTBOUND_END));
  const fuelLine = activeRefuel ? nodePoint(activeRefuel) : null;

  return (
    <svg
      aria-label="Animated readable-scale South Atlantic map of Operation Black Buck refuelling"
      className="h-full w-full"
      preserveAspectRatio="xMidYMid slice"
      viewBox="0 0 1200 760"
    >
      <defs>
        <radialGradient cx="58%" cy="28%" id="oceanGradient" r="72%">
          <stop offset="0%" stopColor="#103656" />
          <stop offset="43%" stopColor="#061b31" />
          <stop offset="100%" stopColor="#010611" />
        </radialGradient>
        <linearGradient id="landGradient" x1="0" x2="1" y1="0" y2="1">
          <stop offset="0%" stopColor="#254456" />
          <stop offset="100%" stopColor="#07131d" />
        </linearGradient>
        <filter height="220%" id="routeGlow" width="220%" x="-60%" y="-60%">
          <feGaussianBlur result="blur" stdDeviation="5" />
          <feColorMatrix
            in="blur"
            result="glow"
            type="matrix"
            values="0 0 0 0 0.13 0 0 0 0 0.91 0 0 0 0 1 0 0 0 0.85 0"
          />
          <feMerge>
            <feMergeNode in="glow" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
        <pattern height="52" id="gridPattern" patternUnits="userSpaceOnUse" width="52">
          <path d="M 52 0 L 0 0 0 52" fill="none" stroke="#8ad7ff" strokeOpacity="0.08" strokeWidth="1" />
        </pattern>
      </defs>

      <rect fill="url(#oceanGradient)" height="760" width="1200" />
      <rect className="map-grid-drift" fill="url(#gridPattern)" height="760" width="1200" />
      <circle className="ocean-bloom bloom-one" cx="700" cy="180" r="260" />
      <circle className="ocean-bloom bloom-two" cx="380" cy="610" r="210" />

      <g opacity="0.7">
        {Array.from({ length: 7 }, (_, index) => (
          <path
            d={`M ${120 + index * 145} 46 C ${95 + index * 145} 270, ${156 + index * 145} 500, ${130 + index * 145} 742`}
            fill="none"
            key={`lon-${index}`}
            stroke="#9bd9ff"
            strokeOpacity="0.09"
            strokeWidth="1"
          />
        ))}
        {Array.from({ length: 6 }, (_, index) => (
          <path
            d={`M 28 ${118 + index * 104} C 330 ${88 + index * 104}, 790 ${150 + index * 104}, 1172 ${112 + index * 104}`}
            fill="none"
            key={`lat-${index}`}
            stroke="#9bd9ff"
            strokeOpacity="0.08"
            strokeWidth="1"
          />
        ))}
      </g>

      <path
        d="M 0 80 C 86 100 136 154 166 232 C 200 322 171 377 223 466 C 268 542 251 620 322 730 L 286 760 L 0 760 Z"
        fill="url(#landGradient)"
        opacity="0.9"
      />
      <path
        d="M 854 0 C 1006 42 1080 138 1112 248 C 1141 350 1092 441 1145 542 C 1170 591 1182 656 1200 710 L 1200 0 Z"
        fill="url(#landGradient)"
        opacity="0.82"
      />
      <path
        d="M 330 628 c 18 -12 42 -12 60 0 c -20 10 -43 14 -60 0 Z M 385 642 c 14 -8 31 -7 44 2 c -17 7 -31 8 -44 -2 Z"
        fill="#31566a"
        opacity="0.9"
      />

      <g className="map-labels">
        <text x="108" y="206">Brazil</text>
        <text x="938" y="220">West Africa</text>
        <text x="308" y="694">Falkland Islands</text>
        <text x="674" y="112">Ascension Island</text>
      </g>

      <g className="route-base">
        <path d={routePathOutbound} />
        <path d={routePathReturn} />
      </g>
      <g filter="url(#routeGlow)">
        <path
          className="route-progress route-out"
          d={routePathOutbound}
          pathLength={1}
          strokeDasharray={1}
          strokeDashoffset={1 - outboundProgress}
        />
        <path
          className="route-progress route-back"
          d={routePathReturn}
          pathLength={1}
          strokeDasharray={1}
          strokeDashoffset={1 - returnProgress}
        />
      </g>
      <path className="route-flow" d={routePathOutbound} opacity={progress < OUTBOUND_END ? 1 : 0.18} />
      <path className="route-flow return-flow" d={routePathReturn} opacity={progress >= OUTBOUND_END ? 1 : 0.18} />

      <g>
        {refuelNodes.map((node) => {
          const point = nodePoint(node);
          const active = activeRefuel?.id === node.id;
          const complete = progress >= node.at;
          const color = node.kind === "relay" ? "#4ea6ff" : node.kind === "recovery" ? "#6ee779" : "#ff6bd8";
          return (
            <g className={`refuel-node ${active ? "active" : ""}`} key={node.id} transform={`translate(${point.x} ${point.y})`}>
              {active && (
                <circle fill="none" r="20" stroke={color} strokeOpacity="0.8" strokeWidth="2">
                  <animate attributeName="r" dur="1.4s" repeatCount="indefinite" values="14;58" />
                  <animate attributeName="opacity" dur="1.4s" repeatCount="indefinite" values="0.9;0" />
                </circle>
              )}
              <circle className="refuel-halo" fill={color} opacity={active ? 0.18 : complete ? 0.08 : 0.03} r={active ? 18 : 12} />
              <circle className="refuel-core" fill={complete ? color : "#dbeafe"} r={node.id === "TGT" ? 7 : 5.5} />
              <text className="refuel-label" y={node.id === "TGT" ? -16 : -12}>
                {node.label}
              </text>
            </g>
          );
        })}
      </g>

      {fuelLine && (
        <g className="fuel-burst" transform={`translate(${fuelLine.x} ${fuelLine.y})`}>
          <path d="M -52 -10 C -26 -28, 28 -28, 52 -10" fill="none" stroke="#e0faff" strokeLinecap="round" strokeWidth="2.5" />
          <path className="fuel-dashes" d="M -50 -10 C -22 -30, 26 -30, 50 -10" fill="none" stroke="#67e8f9" strokeLinecap="round" strokeWidth="4" />
        </g>
      )}

      <g className="aircraft-layer">
        {tankers.map((state, index) => (
          <AircraftMarker key={`${state.label}-${state.wave}-${index}`} state={state} variant="tanker" />
        ))}
        {reserveVulcan && <AircraftMarker state={reserveVulcan} variant="vulcan" />}
        <AircraftMarker state={vulcan} variant="vulcan" />
      </g>

      <g className="base-marker" transform={`translate(${ASCENSION.x} ${ASCENSION.y})`}>
        <circle r="34" stroke="#67e8f9" strokeOpacity="0.24" strokeWidth="1.5" />
        <circle r="7" />
        <circle fill="none" r="18" stroke="#67e8f9" strokeWidth="1.5">
          <animate attributeName="r" dur="3s" repeatCount="indefinite" values="18;54" />
          <animate attributeName="opacity" dur="3s" repeatCount="indefinite" values="0.6;0" />
        </circle>
      </g>
      <g className="target-marker" transform={`translate(${STANLEY.x} ${STANLEY.y})`}>
        <path d="M -18 0 H 18 M 0 -18 V 18" />
        <circle r="26" />
      </g>

      <g className="scale-note">
        <text x="34" y="726">Readable scale: tracks separated and distances compressed for clarity</text>
      </g>
    </svg>
  );
}

function AircraftMarker({ state, variant }: { state: AircraftState; variant: "tanker" | "vulcan" }) {
  const color = state.wave ? waveColors[state.wave] : variant === "vulcan" ? "#ff6bd8" : "#c4e8ff";
  const scale = state.scale ?? 1;
  const opacity = state.dimmed ? 0.42 : 1;
  const label = variant === "vulcan" || state.active ? state.label : state.wave === "recovery" ? "RC" : "V";

  return (
    <g
      className={`aircraft-marker ${state.active ? "active" : ""}`}
      opacity={opacity}
      style={{ "--aircraft-color": color } as CSSProperties}
      transform={`translate(${state.point.x} ${state.point.y}) rotate(${state.angle}) scale(${scale})`}
    >
      <circle className="aircraft-aura" r={variant === "vulcan" ? 20 : 15} />
      {variant === "vulcan" ? <VulcanShape color={color} /> : <VictorShape color={color} />}
      <g transform={`rotate(${-state.angle})`}>
        <text className="aircraft-label" y={variant === "vulcan" ? -24 : -19}>
          {label}
        </text>
      </g>
    </g>
  );
}

function VulcanShape({ color }: { color: string }) {
  return (
    <g>
      <path
        d="M 28 0 L -24 -19 L -10 0 L -24 19 Z"
        fill={color}
        stroke="#fff7ff"
        strokeOpacity="0.76"
        strokeWidth="1.3"
      />
      <path d="M -7 0 H 24" stroke="#fff" strokeLinecap="round" strokeOpacity="0.7" strokeWidth="1.5" />
      <path d="M -26 -5 L -36 -1 M -26 5 L -36 1" stroke={color} strokeLinecap="round" strokeWidth="2" />
    </g>
  );
}

function VictorShape({ color }: { color: string }) {
  return (
    <g>
      <path
        d="M 23 0 L -17 -12 L -8 0 L -17 12 Z"
        fill={color}
        stroke="#f7fbff"
        strokeOpacity="0.72"
        strokeWidth="1.1"
      />
      <path d="M -12 0 H 18" stroke="#ffffff" strokeLinecap="round" strokeOpacity="0.65" strokeWidth="1.2" />
      <path className="hose" d="M -18 0 C -28 2, -34 5, -42 10" fill="none" stroke={color} strokeDasharray="3 4" strokeLinecap="round" strokeWidth="1.8" />
      <circle cx="-44" cy="11" fill="none" r="3.5" stroke={color} strokeWidth="1.7" />
    </g>
  );
}

function ControlDock({
  activePhase,
  activeRefuel,
  distanceFromAscension,
  isPlaying,
  progress,
  refuelsComplete,
  setIsPlaying,
  setProgress,
  setSpeed,
  speed,
  tankerCount,
}: {
  activePhase: Phase;
  activeRefuel?: RefuelNode;
  distanceFromAscension: number;
  isPlaying: boolean;
  progress: number;
  refuelsComplete: number;
  setIsPlaying: (value: boolean | ((current: boolean) => boolean)) => void;
  setProgress: (updater: (current: number) => number) => void;
  setSpeed: (value: number) => void;
  speed: number;
  tankerCount: number;
}) {
  const playLabel = isPlaying ? "Pause" : progress >= 1 ? "Replay" : "Play";

  return (
    <div className="absolute inset-x-0 bottom-0 z-20 border-t border-white/10 bg-slate-950/78 shadow-[0_-28px_80px_rgba(0,0,0,0.42)] backdrop-blur-xl">
      <div className="mx-auto max-w-7xl px-5 py-4 sm:px-8">
        <div className="grid gap-4 lg:grid-cols-[auto_1fr_auto] lg:items-center">
          <div className="flex items-center gap-3">
            <button
              className="grid size-12 place-items-center rounded-full bg-cyan-200 font-bold text-slate-950 shadow-[0_0_34px_rgba(103,232,249,0.34)] transition hover:bg-white"
              onClick={() => {
                if (progress >= 1) setProgress(() => 0);
                setIsPlaying((value) => !value);
              }}
            >
              {isPlaying ? "II" : ">"}
            </button>
            <div>
              <p className="text-xs uppercase tracking-[0.28em] text-cyan-100/60">{playLabel}</p>
              <p className="font-mono text-lg text-white">{formatMissionClock(progress)}</p>
            </div>
          </div>

          <div>
            <div className="mb-3 flex items-center justify-between gap-4 text-xs uppercase tracking-[0.24em] text-slate-400">
              <span>{activePhase.kicker}</span>
              <span>{Math.round(progress * 100)}%</span>
            </div>
            <input
              aria-label="Mission timeline"
              className="mission-range"
              max="1000"
              min="0"
              onChange={(event) => {
                setProgress(() => Number(event.target.value) / 1000);
                setIsPlaying(false);
              }}
              type="range"
              value={Math.round(progress * 1000)}
            />
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              <p className="text-sm text-slate-300">
                <span className="font-semibold text-white">{activeRefuel ? activeRefuel.title : activePhase.title}</span>{" "}
                {activeRefuel ? activeRefuel.detail : activePhase.detail}
              </p>
              <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-sm text-slate-300 sm:justify-end">
                <span>
                  <b className="font-semibold text-white">{tankerCount}</b> tankers airborne
                </span>
                <span>
                  <b className="font-semibold text-white">{refuelsComplete}</b> contacts shown
                </span>
                <span>
                  <b className="font-semibold text-white">{distanceFromAscension.toLocaleString()}</b> km from Ascension
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 lg:justify-end">
            {[0.65, 1, 1.6].map((value) => (
              <button
                className={`rounded-full px-3 py-2 text-xs font-semibold transition ${
                  speed === value ? "bg-white text-slate-950" : "border border-white/15 text-slate-300 hover:border-cyan-200/70 hover:text-white"
                }`}
                key={value}
                onClick={() => setSpeed(value)}
              >
                {value}x
              </button>
            ))}
          </div>
        </div>

        <div className="mt-4 hidden items-center gap-2 lg:flex">
          {phases.map((phase) => (
            <button
              className={`h-1.5 flex-1 rounded-full transition ${progress >= phase.at ? "bg-cyan-200" : "bg-white/14 hover:bg-white/28"}`}
              key={phase.title}
              onClick={() => {
                setProgress(() => phase.at);
                setIsPlaying(false);
              }}
              title={phase.title}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

function FactStat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-3xl font-semibold tracking-[-0.04em] text-white">{value}</p>
      <p className="mt-2 leading-6">{label}</p>
    </div>
  );
}